var searchData=
[
  ['copyright_4',['Copyright',['../page_copyright.html',1,'index']]]
];
