var annotated_dup =
[
    [ "MD_Parola", "class_m_d___parola.html", "class_m_d___parola" ],
    [ "MD_PZone", "class_m_d___p_zone.html", "class_m_d___p_zone" ]
];